<!-- Hi and thanks for using Mapbox! We really appreciate it.

Please do not use this repository and your potential ticket as a place to ask about implementing Mapbox in your project.

Before you post this ticket, please make sure that its topic is about a problem or question related to this demo app.

If you have a general question/issue about implementing Mapbox, please first:

• search for more information on our Android documentation site – https://www.mapbox.com/android-docs/

• search among tickets with the "Android" label in the Mapbox GL-native repository – https://github.com/mapbox/mapbox-gl-native/issues?q=is%3Aissue+is%3Aopen+label%3AAndroid

• search for your issue on Stack Overflow – https://stackoverflow.com/search?tab=newest&q=Mapbox%20%5bandroid%5d

Please contact Mapbox support via https://https://www.mapbox.com/contact/support/#products if you still need assistance or have questions after searching in the resources listed above. -->
